import Button from "@components/buttons/Button";

function App() {
  return (
    <div className="">
      <Button colour="primary">hello</Button>
      <Button colour="secondary">hello</Button>
      <Button colour="accent">hello</Button>
      <Button colour="text">hello</Button>
      <Button colour="background">hello</Button>
    </div>
  );
}

export default App;
